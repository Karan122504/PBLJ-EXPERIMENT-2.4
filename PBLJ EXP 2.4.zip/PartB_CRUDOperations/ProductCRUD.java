package com.example.productcrud;

import java.sql.*;
import java.util.Scanner;

public class ProductCRUD {
    private static final String URL = "jdbc:mysql://localhost:3306/productdb";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner sc = new Scanner(System.in)) {

            Class.forName("com.mysql.cj.jdbc.Driver");
            con.setAutoCommit(false);

            while (true) {
                System.out.println("\n1. Insert Product");
                System.out.println("2. View Products");
                System.out.println("3. Update Product");
                System.out.println("4. Delete Product");
                System.out.println("5. Exit");
                System.out.print("Enter choice: ");
                int choice = sc.nextInt();

                switch (choice) {
                    case 1:
                        insertProduct(con, sc);
                        break;
                    case 2:
                        viewProducts(con);
                        break;
                    case 3:
                        updateProduct(con, sc);
                        break;
                    case 4:
                        deleteProduct(con, sc);
                        break;
                    case 5:
                        con.close();
                        System.exit(0);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void insertProduct(Connection con, Scanner sc) throws SQLException {
        System.out.print("Enter ProductID, Name, Price, Quantity: ");
        int id = sc.nextInt();
        String name = sc.next();
        double price = sc.nextDouble();
        int qty = sc.nextInt();

        PreparedStatement ps = con.prepareStatement("INSERT INTO Product VALUES (?, ?, ?, ?)");
        ps.setInt(1, id);
        ps.setString(2, name);
        ps.setDouble(3, price);
        ps.setInt(4, qty);
        ps.executeUpdate();
        con.commit();
        System.out.println("Product inserted successfully!");
    }

    private static void viewProducts(Connection con) throws SQLException {
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM Product");
        System.out.println("ProductID\tName\tPrice\tQuantity");
        while (rs.next()) {
            System.out.println(rs.getInt("ProductID") + "\t" +
                               rs.getString("ProductName") + "\t" +
                               rs.getDouble("Price") + "\t" +
                               rs.getInt("Quantity"));
        }
    }

    private static void updateProduct(Connection con, Scanner sc) throws SQLException {
        System.out.print("Enter ProductID to update: ");
        int id = sc.nextInt();
        System.out.print("Enter new Price: ");
        double price = sc.nextDouble();

        PreparedStatement ps = con.prepareStatement("UPDATE Product SET Price=? WHERE ProductID=?");
        ps.setDouble(1, price);
        ps.setInt(2, id);
        int rows = ps.executeUpdate();
        if (rows > 0) {
            con.commit();
            System.out.println("Product updated successfully!");
        } else {
            con.rollback();
            System.out.println("Product not found!");
        }
    }

    private static void deleteProduct(Connection con, Scanner sc) throws SQLException {
        System.out.print("Enter ProductID to delete: ");
        int id = sc.nextInt();

        PreparedStatement ps = con.prepareStatement("DELETE FROM Product WHERE ProductID=?");
        ps.setInt(1, id);
        int rows = ps.executeUpdate();
        if (rows > 0) {
            con.commit();
            System.out.println("Product deleted successfully!");
        } else {
            con.rollback();
            System.out.println("Product not found!");
        }
    }
}
