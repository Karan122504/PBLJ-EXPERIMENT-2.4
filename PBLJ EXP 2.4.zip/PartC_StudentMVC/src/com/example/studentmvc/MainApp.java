package com.example.studentmvc;

import com.example.studentmvc.controller.StudentController;
import com.example.studentmvc.model.Student;
import com.example.studentmvc.view.StudentView;

public class MainApp {
    public static void main(String[] args) {
        try {
            StudentController controller = new StudentController();
            StudentView view = new StudentView();

            while (true) {
                int choice = view.showMenu();
                switch (choice) {
                    case 1:
                        System.out.print("Enter ID, Name, Department, Marks: ");
                        int id = view.getScanner().nextInt();
                        String name = view.getScanner().next();
                        String dept = view.getScanner().next();
                        double marks = view.getScanner().nextDouble();
                        controller.addStudent(new Student(id, name, dept, marks));
                        break;
                    case 2:
                        controller.viewStudents();
                        break;
                    case 3:
                        System.out.print("Enter ID and new Marks: ");
                        id = view.getScanner().nextInt();
                        marks = view.getScanner().nextDouble();
                        controller.updateStudent(id, marks);
                        break;
                    case 4:
                        System.out.print("Enter ID to delete: ");
                        id = view.getScanner().nextInt();
                        controller.deleteStudent(id);
                        break;
                    case 5:
                        System.exit(0);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
