package com.example.studentmvc.controller;

import com.example.studentmvc.model.Student;
import java.sql.*;
import java.util.*;

public class StudentController {
    private Connection con;

    public StudentController() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "password");
    }

    public void addStudent(Student s) throws SQLException {
        PreparedStatement ps = con.prepareStatement("INSERT INTO Student VALUES (?, ?, ?, ?)");
        ps.setInt(1, s.getStudentID());
        ps.setString(2, s.getName());
        ps.setString(3, s.getDepartment());
        ps.setDouble(4, s.getMarks());
        ps.executeUpdate();
        System.out.println("Student added successfully!");
    }

    public void viewStudents() throws SQLException {
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM Student");
        System.out.println("ID\tName\tDepartment\tMarks");
        while (rs.next()) {
            System.out.println(rs.getInt(1) + "\t" +
                               rs.getString(2) + "\t" +
                               rs.getString(3) + "\t" +
                               rs.getDouble(4));
        }
    }

    public void updateStudent(int id, double marks) throws SQLException {
        PreparedStatement ps = con.prepareStatement("UPDATE Student SET Marks=? WHERE StudentID=?");
        ps.setDouble(1, marks);
        ps.setInt(2, id);
        ps.executeUpdate();
        System.out.println("Student updated successfully!");
    }

    public void deleteStudent(int id) throws SQLException {
        PreparedStatement ps = con.prepareStatement("DELETE FROM Student WHERE StudentID=?");
        ps.setInt(1, id);
        ps.executeUpdate();
        System.out.println("Student deleted successfully!");
    }
}
