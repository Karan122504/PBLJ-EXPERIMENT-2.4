package com.example.studentmvc.view;

import java.util.Scanner;

public class StudentView {
    private Scanner sc = new Scanner(System.in);

    public int showMenu() {
        System.out.println("\n1. Add Student");
        System.out.println("2. View Students");
        System.out.println("3. Update Student");
        System.out.println("4. Delete Student");
        System.out.println("5. Exit");
        System.out.print("Enter choice: ");
        return sc.nextInt();
    }

    public Scanner getScanner() {
        return sc;
    }
}
