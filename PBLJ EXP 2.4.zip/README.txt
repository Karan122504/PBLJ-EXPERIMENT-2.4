Java Applications Using JDBC for Database Connectivity, CRUD Operations, and MVC Architecture

Part A - Connects to MySQL and fetches Employee data.
Part B - Performs CRUD operations on Product table with transaction handling.
Part C - Implements MVC architecture for Student management using JDBC.

Database setup:
- MySQL host: localhost
- port: 3306
- username: root
- password: password
